import ItemCount from "../ItemCount";
function ItemDetail(){
    return <div>

    <ItemCount stock={producto.stock} onAdd={onAdd}/>
    </div>
}

export default ItemDetail;