function ItemDetailContainer(){
    return <div></div>
}

export default ItemDetailContainer;