import ItemCount from "../ItemCount";
import "./item.css"
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';


function Item ({producto}){
    const onAdd = (cant) => {console.log("Se agregaron "+cant)}
    return <Col xs={3} className="card"> 
        <img src={producto.img} alt="" className="imgLista"/>
        <p>{producto.name}</p>
        <Button variant="primary">Ver Detalle</Button>{' '}
    </Col>
}
export default Item;