import './itemcount.css'
import { useState } from 'react';
function ItemCount({stock,onAdd}){

   const [cant,setCant]=useState(1);

   const sumar = () => {
    if(stock>cant)
        setCant(cant + 1);
   }
   const restar = () => {
    if(cant>1)
        setCant(cant - 1);
   }
   const agregar = ()=>{
    if(stock>0)
        onAdd(cant);
   }
    return (<div>
        <div className='lineaBotones'>
            <button onClick={restar}>-</button>
            <p>{cant}</p>
            <button onClick={sumar}>+</button>
        </div>
        <button onClick={agregar}>Agregar Al carrito</button>
    </div>)
}



export default ItemCount;