import NavBar from "../components/NavBar";
import ItemDetailContainer from "../components/ItemDetailContainer";

function ItemRoot() {
  return (
    <div className="contenedor">
      <NavBar /> 
      <ItemDetailContainer props="Aca van a estar los productos posiblemente"/>  
    </div>
  );
}

export default ItemRoot;
