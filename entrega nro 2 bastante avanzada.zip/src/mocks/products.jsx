import produ1 from "../assets/calathea.jpeg"
import produ2 from "../assets/dipladenia.png"
import produ3 from "../assets/helecho.jpeg"
import produ4 from "../assets/impatiens.webp"
import produ5 from "../assets/lantana.jpg"
import produ6 from "../assets/lavanda.jpg"
import produ7 from "../assets/orquidea.jpg"
import produ8 from "../assets/sanseviera.jpg"
import produ9 from "../assets/sterlizia.webp"
export default [
    {
        id: 1,
        name: "Calathea stromante",
        descripcion: "lorem ipsum",
        img: produ1,
        stock: 4,
        category: "interior",
    },
    {
        id: 2,
        name: "Dipladenia",
        descripcion: "lorem ipsum",
        img: produ2,
        stock: 6,
        category: "sombra",
    },
    {
        id: 3,
        name: "Helecho",
        descripcion: "lorem ipsum",
        img: produ3,
        stock: 10,
        category: "interior",
    },
    {
        id: 4,
        name: "Impatiens",
        descripcion: "lorem ipsum",
        img: produ4,
        stock: 3,
        category: "sombra",
    },
    {
        id: 5,
        name: "Lantana",
        descripcion: "lorem ipsum",
        img: produ5,
        stock: 2,
        category: "exterior",
    },
    {
        id: 6,
        name: "Lavanda",
        descripcion: "lorem ipsum",
        img: produ6,
        stock: 5,
        category: "exterior",
    },
    {
        id: 7,
        name: "Orquidea Phaleanopsis",
        descripcion: "lorem ipsum",
        img: produ7,
        stock: 5,
        category: "sombra",
    },
    {
        id: 8,
        name: "Sanseviera",
        descripcion: "lorem ipsum",
        img: produ8,
        stock: 9,
        category: "interior",
    },
    {
        id: 9,
        name: "Sterlizia Nicolai",
        descripcion: "lorem ipsum",
        img: produ9,
        stock: 9,
        category: "sombra",
    }
];